#!/bin/bash
export OMP_NUM_THREADS=1

host=${1:-localhost}
teamname=${2:-FCPortugal}

python3 ./Script_Official_Player.py -i $host -t $teamname -P 1 -u 1 &
python3 ./Script_Official_Player.py -i $host -t $teamname -P 1 -u 11 &