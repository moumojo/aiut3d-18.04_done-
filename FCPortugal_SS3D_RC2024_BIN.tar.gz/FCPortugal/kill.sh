#!/bin/bash

killall fcp
sleep 1
killall -9 fcp

