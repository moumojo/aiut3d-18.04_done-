#!/bin/bash

# Kill agents
AGENT="wrightocean"
killall -9 $AGENT
sleep 1

